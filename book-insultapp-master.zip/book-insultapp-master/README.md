OpenShift 3 Java EE Insult Application
====================

This repository contains a sample application for the book *Getting Started with Java on OpenShift*

