package com.scb.microservice;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/test")
public class TestController {


    @RequestMapping(method = RequestMethod.GET,path="/{id}")
    public String testGetController(@PathVariable String id){


        return "Http_Get_Status id is "+id;
    }
}
